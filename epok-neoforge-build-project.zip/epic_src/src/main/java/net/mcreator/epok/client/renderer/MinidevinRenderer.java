package net.mcreator.epok.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.HumanoidModel;

import net.mcreator.epok.entity.MinidevinEntity;

public class MinidevinRenderer extends HumanoidMobRenderer<MinidevinEntity, HumanoidModel<MinidevinEntity>> {
	private final ResourceLocation entityTexture = ResourceLocation.parse("epok:textures/entities/devin.png");

	public MinidevinRenderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel<MinidevinEntity>(context.bakeLayer(ModelLayers.PLAYER)), 0.3f);
		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)), new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), context.getModelManager()));
	}

	@Override
	public ResourceLocation getTextureLocation(MinidevinEntity entity) {
		return entityTexture;
	}
}