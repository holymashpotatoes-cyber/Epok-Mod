/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.epok.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.registries.Registries;

import net.mcreator.epok.entity.MinidevinEntity;
import net.mcreator.epok.entity.MOUSEEntity;
import net.mcreator.epok.EpokMod;

@EventBusSubscriber
public class EpokModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, EpokMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<MOUSEEntity>> MOUSE = register("mouse",
			EntityType.Builder.<MOUSEEntity>of(MOUSEEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.6f, 0.7f));
	public static final DeferredHolder<EntityType<?>, EntityType<MinidevinEntity>> MINIDEVIN = register("minidevin",
			EntityType.Builder.<MinidevinEntity>of(MinidevinEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(80).setUpdateInterval(3)

					.ridingOffset(-0.6f).sized(0.6f, 1.8f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(RegisterSpawnPlacementsEvent event) {
		MOUSEEntity.init(event);
		MinidevinEntity.init(event);
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(MOUSE.get(), MOUSEEntity.createAttributes().build());
		event.put(MINIDEVIN.get(), MinidevinEntity.createAttributes().build());
	}
}