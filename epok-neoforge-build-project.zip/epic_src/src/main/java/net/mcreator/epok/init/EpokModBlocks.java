/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.epok.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.Block;

import net.mcreator.epok.block.YELOWWATERBlock;
import net.mcreator.epok.block.ChezPortalBlock;
import net.mcreator.epok.block.CheeseBlock;
import net.mcreator.epok.block.AhuginatorBlock;
import net.mcreator.epok.EpokMod;

public class EpokModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(EpokMod.MODID);
	public static final DeferredBlock<Block> CHEESE;
	public static final DeferredBlock<Block> YELOWWATER;
	public static final DeferredBlock<Block> CHEZ_PORTAL;
	public static final DeferredBlock<Block> AHUGINATOR;
	static {
		CHEESE = REGISTRY.register("cheese", CheeseBlock::new);
		YELOWWATER = REGISTRY.register("yelowwater", YELOWWATERBlock::new);
		CHEZ_PORTAL = REGISTRY.register("chez_portal", ChezPortalBlock::new);
		AHUGINATOR = REGISTRY.register("ahuginator", AhuginatorBlock::new);
	}
	// Start of user code block custom blocks
	// End of user code block custom blocks
}