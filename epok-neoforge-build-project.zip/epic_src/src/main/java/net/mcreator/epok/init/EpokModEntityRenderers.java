/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.epok.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.epok.client.renderer.MinidevinRenderer;
import net.mcreator.epok.client.renderer.MOUSERenderer;

@EventBusSubscriber(Dist.CLIENT)
public class EpokModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(EpokModEntities.MOUSE.get(), MOUSERenderer::new);
		event.registerEntityRenderer(EpokModEntities.MINIDEVIN.get(), MinidevinRenderer::new);
	}
}