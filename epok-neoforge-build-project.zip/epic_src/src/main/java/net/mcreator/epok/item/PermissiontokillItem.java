package net.mcreator.epok.item;

import net.minecraft.world.item.Item;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.epok.EpokMod;

public class PermissiontokillItem extends Item {
	public PermissiontokillItem() {
		super(new Item.Properties().jukeboxPlayable(ResourceKey.create(Registries.JUKEBOX_SONG, ResourceLocation.fromNamespaceAndPath(EpokMod.MODID, "permissiontokill"))));
	}
}