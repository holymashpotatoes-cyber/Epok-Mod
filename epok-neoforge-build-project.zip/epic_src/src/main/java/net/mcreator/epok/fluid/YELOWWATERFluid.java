package net.mcreator.epok.fluid;

import net.neoforged.neoforge.fluids.BaseFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.epok.init.EpokModItems;
import net.mcreator.epok.init.EpokModFluids;
import net.mcreator.epok.init.EpokModFluidTypes;
import net.mcreator.epok.init.EpokModBlocks;

public abstract class YELOWWATERFluid extends BaseFlowingFluid {
	public static final BaseFlowingFluid.Properties PROPERTIES = new BaseFlowingFluid.Properties(() -> EpokModFluidTypes.YELOWWATER_TYPE.get(), () -> EpokModFluids.YELOWWATER.get(), () -> EpokModFluids.FLOWING_YELOWWATER.get())
			.explosionResistance(100f).bucket(() -> EpokModItems.YELOWWATER_BUCKET.get()).block(() -> (LiquidBlock) EpokModBlocks.YELOWWATER.get());

	private YELOWWATERFluid() {
		super(PROPERTIES);
	}

	public static class Source extends YELOWWATERFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends YELOWWATERFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}