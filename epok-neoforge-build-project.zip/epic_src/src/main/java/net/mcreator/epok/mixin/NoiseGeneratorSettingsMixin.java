package net.mcreator.epok.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.core.Holder;

import net.mcreator.epok.init.EpokModBiomes;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements EpokModBiomes.EpokModNoiseGeneratorSettings {
	@Unique
	private Holder<DimensionType> epok_dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public SurfaceRules.RuleSource surfaceRule(Operation<SurfaceRules.RuleSource> original) {
		SurfaceRules.RuleSource retval = original.call();
		if (this.epok_dimensionTypeReference != null) {
			retval = EpokModBiomes.adaptSurfaceRule(retval, this.epok_dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void setepokDimensionTypeReference(Holder<DimensionType> dimensionType) {
		this.epok_dimensionTypeReference = dimensionType;
	}
}