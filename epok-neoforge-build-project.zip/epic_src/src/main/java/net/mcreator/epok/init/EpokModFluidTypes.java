/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.epok.init;

import net.neoforged.neoforge.registries.NeoForgeRegistries;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.fluids.FluidType;

import net.mcreator.epok.fluid.types.YELOWWATERFluidType;
import net.mcreator.epok.EpokMod;

public class EpokModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(NeoForgeRegistries.FLUID_TYPES, EpokMod.MODID);
	public static final DeferredHolder<FluidType, FluidType> YELOWWATER_TYPE = REGISTRY.register("yelowwater", YELOWWATERFluidType::new);
}