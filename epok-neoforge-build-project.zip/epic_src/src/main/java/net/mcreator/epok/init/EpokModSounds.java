/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.epok.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

import net.mcreator.epok.EpokMod;

public class EpokModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, EpokMod.MODID);
	public static final DeferredHolder<SoundEvent, SoundEvent> KILL = REGISTRY.register("kill", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("epok", "kill")));
}