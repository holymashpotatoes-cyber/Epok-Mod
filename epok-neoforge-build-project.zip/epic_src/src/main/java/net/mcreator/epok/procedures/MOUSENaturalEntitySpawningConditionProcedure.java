package net.mcreator.epok.procedures;

public class MOUSENaturalEntitySpawningConditionProcedure {
	public static void execute() {
	}
}