package net.mcreator.epok.item;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.epok.init.EpokModFluids;

public class YELOWWATERItem extends BucketItem {
	public YELOWWATERItem() {
		super(EpokModFluids.YELOWWATER.get(), new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1)

		);
	}
}