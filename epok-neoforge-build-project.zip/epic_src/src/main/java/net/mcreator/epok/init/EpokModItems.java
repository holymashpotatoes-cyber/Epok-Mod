/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.epok.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.fluids.capability.wrappers.FluidBucketWrapper;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.epok.item.YELOWWATERItem;
import net.mcreator.epok.item.PermissiontokillItem;
import net.mcreator.epok.item.ChezItem;
import net.mcreator.epok.EpokMod;

@EventBusSubscriber
public class EpokModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(EpokMod.MODID);
	public static final DeferredItem<Item> CHEESE;
	public static final DeferredItem<Item> YELOWWATER_BUCKET;
	public static final DeferredItem<Item> CHEZ;
	public static final DeferredItem<Item> MOUSE_SPAWN_EGG;
	public static final DeferredItem<Item> PERMISSIONTOKILL;
	public static final DeferredItem<Item> AHUGINATOR;
	public static final DeferredItem<Item> MINIDEVIN_SPAWN_EGG;
	static {
		CHEESE = block(EpokModBlocks.CHEESE);
		YELOWWATER_BUCKET = REGISTRY.register("yelowwater_bucket", YELOWWATERItem::new);
		CHEZ = REGISTRY.register("chez", ChezItem::new);
		MOUSE_SPAWN_EGG = REGISTRY.register("mouse_spawn_egg", () -> new DeferredSpawnEggItem(EpokModEntities.MOUSE, -1, -1, new Item.Properties()));
		PERMISSIONTOKILL = REGISTRY.register("permissiontokill", PermissiontokillItem::new);
		AHUGINATOR = block(EpokModBlocks.AHUGINATOR);
		MINIDEVIN_SPAWN_EGG = REGISTRY.register("minidevin_spawn_egg", () -> new DeferredSpawnEggItem(EpokModEntities.MINIDEVIN, -52, -16777216, new Item.Properties()));
	}

	// Start of user code block custom items
	// End of user code block custom items
	@SubscribeEvent
	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		event.registerItem(Capabilities.FluidHandler.ITEM, (stack, context) -> new FluidBucketWrapper(stack), YELOWWATER_BUCKET.get());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), properties));
	}
}