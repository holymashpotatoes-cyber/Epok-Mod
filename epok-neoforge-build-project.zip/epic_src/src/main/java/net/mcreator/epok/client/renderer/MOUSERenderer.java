package net.mcreator.epok.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.OcelotModel;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.animation.definitions.FrogAnimation;

import net.mcreator.epok.entity.MOUSEEntity;

public class MOUSERenderer extends MobRenderer<MOUSEEntity, OcelotModel<MOUSEEntity>> {
	private final ResourceLocation entityTexture = ResourceLocation.parse("epok:textures/entities/all_black.png");

	public MOUSERenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(ModelLayers.OCELOT)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(MOUSEEntity entity) {
		return entityTexture;
	}

	private static final class AnimatedModel extends OcelotModel<MOUSEEntity> {
		private final ModelPart root;
		private final HierarchicalModel animator = new HierarchicalModel<MOUSEEntity>() {
			@Override
			public ModelPart root() {
				return root;
			}

			@Override
			public void setupAnim(MOUSEEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
				this.root().getAllParts().forEach(ModelPart::resetPose);
				this.animate(entity.animationState0, FrogAnimation.FROG_JUMP, ageInTicks, 1f);
			}
		};

		public AnimatedModel(ModelPart root) {
			super(root);
			this.root = root;
		}

		@Override
		public void setupAnim(MOUSEEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
			animator.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
			super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
		}
	}
}