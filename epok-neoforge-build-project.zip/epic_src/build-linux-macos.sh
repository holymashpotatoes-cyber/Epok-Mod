#!/usr/bin/env bash
set -euo pipefail
if ! command -v java >/dev/null 2>&1; then echo 'Java 21 is required.' >&2; exit 1; fi
if ! command -v gradle >/dev/null 2>&1; then echo 'Gradle 8.10.2 or newer is required.' >&2; exit 1; fi
gradle --no-daemon clean build
echo 'Build complete: build/libs/epok-1.0.0.jar'
