EPOK - Minecraft 1.21.1 NeoForge project

This is a BUILDABLE SOURCE PROJECT, NOT an installable mod JAR. The original
source ZIP already contains the NeoForge metadata file at:
src/main/resources/META-INF/neoforge.mods.toml

The Gradle build configuration targets Java 21, Minecraft 1.21.1, and
NeoForge 21.1.232. To create the installable JAR, use a computer with internet
access, Java 21, and Gradle 8.10.2 or newer:

Windows: double-click build-windows.bat
Linux/macOS: run ./build-linux-macos.sh
Or run: gradle --no-daemon clean build

The output should be build/libs/epok-1.0.0.jar. Install THAT JAR (not this ZIP)
in the mods folder of a Minecraft 1.21.1 NeoForge server. The server and client
must use compatible mod versions.

IMPORTANT LIMITATIONS:
- This environment has Java 21 but no Gradle installation, no cached NeoForge
  dependencies, and no network/DNS access, so I cannot compile or test the JAR
  here. The build script is prepared, but a successful build is not verified.
- Arclight is a hybrid server. Even if the JAR builds, its mixins, custom
  dimension, entities, and other features may not all be compatible with your
  specific Arclight build. Test on a copy/backup of your world first.
