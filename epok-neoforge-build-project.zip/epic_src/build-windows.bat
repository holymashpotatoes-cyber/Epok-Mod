@echo off
setlocal
where java >nul 2>nul || (echo Java is not installed. Install Java 21 first.& pause& exit /b 1)
where gradle >nul 2>nul || (echo Gradle is not installed or not on PATH. Install Gradle 8.10.2 or newer first.& pause& exit /b 1)
echo Building Epok for Minecraft 1.21.1 / NeoForge 21.1.232...
gradle --no-daemon clean build
if errorlevel 1 (echo BUILD FAILED. Send me the full error above.& pause& exit /b 1)
echo.
echo BUILD COMPLETE: build\libs\epok-1.0.0.jar
echo Copy that JAR into the server's mods folder.
pause
